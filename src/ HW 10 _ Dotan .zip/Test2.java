/** Tests the construction of a list of CharData objects. */
public class Test2 {
	
	public static void main(String args[]) {
	    testBuildList();
		testBuildListWithProbabilities();
	}

	public static void testBuildList() {
		System.out.println("Testing the construction of a list of CharData objects " + 
			               "from a given string input.");
		System.out.println("The probability fields of the CharData objects will be initialized to 0.");
		String input = "committee ";
		System.out.println("Input = \"" + input + "\"");
		List q = buildList(input);
		System.out.println("List = " + q);	
		System.out.println();		
	}

	public static void testBuildListWithProbabilities() {
		System.out.println("Testing the construction of a list of CharData objects " + 
			               "from a given string input.");
		System.out.println("This time, the probability fields will be computed and set correctly.");
		String input = "committee ";
		System.out.println("Input = \"" + input + "\"");
		List q = buildList(input);
		// Calcualates the probalities
		calculateProbabilities(q);
		// Prints the list with the calculates probabilities
		System.out.println("List =  " + q);	
		System.out.println();	
	}
	
	// Builds a list of CharData objects from a given string.
	private static List buildList(String input) {
		// Replace the following statement with your code
		List q = new List();
		for (int i = 0; i <input.length() ; i++) {
			q.update(input.charAt(i));
		}
		return q;
	}

	// Computes and sets the probabilities (p and pp fields) in all the
	// CharData objects in the given list.
	public static void calculateProbabilities(List list) {				
		// Write your code here.
		double totalCount = 0;
		for (int i = 0; i < list.getSize(); i++) {
			totalCount = totalCount +  list.get(i).count;
		}
		for (int i = 0; i <list.getSize(); i++) {
			if (i == 0){
				list.get(i).p = list.get(i).count / totalCount ;
				list.get(i).pp = list.get(i).p;
			}else {
				list.get(i).p = list.get(i).count / totalCount;
				list.get(i).pp = list.get(i).p + list.get(i - 1).pp;
			}
		}


	}
}
